package hcmute.edu.vn.sample1;

import static android.graphics.BitmapFactory.*;
import static hcmute.edu.vn.sample1.Service.ApplicationClass.ACTION_NEXT;
import static hcmute.edu.vn.sample1.Service.ApplicationClass.ACTION_PLAY;
import static hcmute.edu.vn.sample1.Service.ApplicationClass.ACTION_PREV;
import static hcmute.edu.vn.sample1.Service.ApplicationClass.CHANNEL_ID_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.media.session.MediaSessionCompat;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import de.hdodenhof.circleimageview.CircleImageView;
import hcmute.edu.vn.sample1.Adapter.DiskAdapter;
import hcmute.edu.vn.sample1.Fragment.DiskFragment;
import hcmute.edu.vn.sample1.Interface.ActionPlaying;
import hcmute.edu.vn.sample1.model.song;

public class PlayerActivity extends AppCompatActivity implements ServiceConnection, ActionPlaying {

    int currIndex = 0;
    ImageButton btnPlay, btnNext, btnPrevious, btnLoopSong, btnShuffleSong;
    TextView txtSongName, txtSongStart, txtSongEnd, txtArtist, txtTimeStart, txtTimeRunning;
    SeekBar mSeekBar;
    private DiskFragment discFragment;
    ViewPager viewPagerDisc;
    private DiskAdapter diskAdapter;
    ArrayList<song> songList;
    List<song> mSongList;

    ImageView imageView;
    private SQLiteDatabase db;
    private androidx.appcompat.widget.Toolbar toolbarplaynhac;

    private int dem = 0, position = 0, duration = 0, timeValue = 0, durationToService = 0;
    private boolean repeat = false, checkrandom = false, isplaying;
    private song Song;
    private static ArrayList<song> mangbaihat = new ArrayList<>();

    private String taikhoan;
    private Thread playThread, prevThread, nextThread;

    private CircleImageView circleImageView;
    public static final String EXTRA_NAME = "songname";
    static MediaPlayer mediaPlayer;
    Handler handler;

    // set for show notification
    MusicService musicService;
    MediaSessionCompat mediaSessionCompat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        mediaSessionCompat = new MediaSessionCompat(this, "MySessionTag");
        btnPrevious = (ImageButton) findViewById(R.id.imageButtonpreview);
        btnNext = (ImageButton) findViewById(R.id.imageButtonnext);
        btnPlay = (ImageButton) findViewById(R.id.imageButtonplaypause);
        btnLoopSong = (ImageButton) findViewById(R.id.imageButtonlap);
        btnShuffleSong = (ImageButton) findViewById(R.id.imageButtontron);

        txtSongName = (TextView) findViewById(R.id.textViewtenbaihatplaynhac);
        txtArtist = (TextView) findViewById(R.id.textViewtencasiplaynhac);
        txtTimeStart = findViewById(R.id.textViewtimetotal);
        txtTimeRunning = findViewById(R.id.textViewruntime);

        mSeekBar = findViewById(R.id.seekBartime);
        circleImageView = findViewById(R.id.viewCirlerdianhac);


        if (mediaPlayer != null) {


            mediaPlayer.start();
            mediaPlayer.release();
        }

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        songList = (ArrayList) bundle.getParcelableArrayList("songs");
        String sName = intent.getStringExtra("songname");
        position = bundle.getInt("pos", 0);


//         txtSongName.setSelected(true);
//         Uri uri = Uri.parse(songList.get(position).getSongURL());
//
//         String songName = songList.get(position).getSongName();
//        Log.e("file from firebase: ", uri.toString());
//            String songArtist = songList.get(position).getSongArtist();
//            String songTotalTime = songList.get(position).getSongduration();
//         txtSongName.setText(songName);
//         txtArtist.setText(songArtist);
//         txtTimeStart.setText(songTotalTime);
//        // set seekbar maximum duration
//
//
//
//         btnPlay.setBackgroundResource(R.drawable.nutplay);
//
//
//            showCurrentArtwork();
//

        circleImageView.setAnimation(loadRotation());
//
//        // Play song
//         mediaPlayer = MediaPlayer.create(getApplicationContext(), uri);
//         mediaPlayer.start();

        initPlayer(position);
        mSeekBar.setRotation(180);


        // icon Play Song
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mediaPlayer.isPlaying()) {
                    btnPlay.setBackgroundResource(R.drawable.nutpause);
                    mediaPlayer.pause();
                } else {
                    btnPlay.setBackgroundResource(R.drawable.nutplay);
                    mediaPlayer.start();
                }
            }
        });

        // button for next Song
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (position < songList.size() - 1) {
                    position++;
                } else {
                    position = 0;

                }
                initPlayer(position);

                if (mediaPlayer.isPlaying())
                    // mới chỉnh chỗ này 11:00 25/4/2023
                    showNotification(R.drawable.nutpause);
                else
                    showNotification(R.drawable.nutplay);
            }
        });

        // button for prevous Song
        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (position <= 0) {
                    position = songList.size() - 1;
                } else {
                    position--;
                }

                initPlayer(position);

                if (mediaPlayer.isPlaying())
                    showNotification(R.drawable.nutpause);
                else
                    showNotification(R.drawable.nutplay);
            }
        });

        // loop song
        btnLoopSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
            }
        });

        //random songs
        btnShuffleSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            Random rand = new Random();
                            position = rand.nextInt((songList.size() - 1) - 0 + 1) + 0;

                            initPlayer(position);
                        }
                    });
                } else {
                    Random rand = new Random();
                    position = rand.nextInt((songList.size() - 1) - 0 + 1) + 0;
                    initPlayer(position);
                }
            }
        });


        // for progressbar
        mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    mediaPlayer.seekTo(progress);
                    mSeekBar.setProgress(position);

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        // Khởi tạo và bắt đầu Thread để cập nhật vị trí của SeekBar
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (mediaPlayer != null) {
                    try {
                        if (mediaPlayer.isPlaying()) {
                            Message msg = new Message();
                            msg.what = mediaPlayer.getCurrentPosition();
                            handle2r.sendMessage(msg);
                            Thread.sleep(1000);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        }).start();
    }


    // function play Song, create to tái sử dụng để set event cho Next, Previous
    private void initPlayer(final int position) {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.reset();
        }

        txtSongName.setSelected(true);
        //Uri songResourceUri = Uri.parse(songList.get(position).getSongURL());
        Uri songResourceUri = Uri.parse(songList.get(position).getSongURL());

        String songName = songList.get(position).getSongName();

        Log.e("file from firebase: ", songResourceUri.toString());
        String songArtist = songList.get(position).getSongArtist();
        String songTotalTime = songList.get(position).getSongduration();
        txtSongName.setText(songName);
        txtArtist.setText(songArtist);
        txtTimeStart.setText(songTotalTime);
        // set seekbar maximum duration

        mediaPlayer = MediaPlayer.create(getApplicationContext(), songResourceUri); // create and load mediaplayer with song resources
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                String totalTime = createTimeLabel(mediaPlayer.getDuration());
                //songTotalTime.setText(totalTime);
                //mSeekBar.setMax(mediaPlayer.getDuration());
                mediaPlayer.start();
                showNotification(R.drawable.nutpause); // sai xoa
                btnPlay.setBackgroundResource(R.drawable.nutplay);

            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                int curSongPoition = position;
                // code to repeat songs until the
                if (curSongPoition < songList.size() - 1) {
                    curSongPoition++;
                    initPlayer(curSongPoition);
                } else {
                    curSongPoition = 0;
                    initPlayer(curSongPoition);
                }

                showNotification(R.drawable.nutplay); // sai xoa
                btnPlay.setBackgroundResource(R.drawable.nutplay);


            }
        });


        showCurrentArtwork();
        showNotification(R.drawable.nutpause);
        circleImageView.setAnimation(loadRotation());
    }


    // random songs
    private void playRandomSong() {
//        // Get a random song from the songList
//        int randomIndex = new Random().nextInt(songList.size());
//        int songResId = songList.get(randomIndex);
//
//        // Stop and release any previous MediaPlayer instance
//        if (mediaPlayer != null) {
//            mediaPlayer.stop();
//            mediaPlayer.release();
//        }
//
//        // Create a new MediaPlayer instance with the random song
//        mediaPlayer = MediaPlayer.create(this, songResId);
//
//        // Start playing the song
//        mediaPlayer.start();

        Random rand = new Random();
        position = rand.nextInt((songList.size() - 1) - 0 + 1) + 0;
        initPlayer(position);
    }

    //
    @SuppressLint("HandlerLeak")
    private Handler handle2r = new Handler() {
        @Override
        public void handleMessage(Message msg) {
//            Log.i("handler ", "handler called");
            int current_position = msg.what;
            mSeekBar.setProgress(current_position);
            String cTime = createTimeLabel(current_position);
            txtTimeRunning.setText(cTime);
        }
    };
    // end progress bar


    /* private Animation loadRotation(){
         //RotateAnimation rotateAnimation = new RotateAnimation(0,360)
     }*/
    private void showCurrentArtwork() {
        Uri uri = Uri.parse(songList.get(position).getImageurl());
        Glide.with(getApplicationContext())
                .load(uri)
                .into(circleImageView);

        if (circleImageView == null) {
            circleImageView.setImageResource(R.drawable.img);
        }
    }

    private Animation loadRotation() {
        RotateAnimation rotateAnimation = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateAnimation.setInterpolator(new LinearInterpolator());
        rotateAnimation.setDuration(10000);
        rotateAnimation.setRepeatCount(Animation.INFINITE);
        return rotateAnimation;
    }

    // new function to calculate init time before starting to ending of the song

    public String createTimeLabel(int duration) {
        String timeLabel = "";
        int min = duration / 1000 / 60;
        int sec = duration / 1000 % 60;

        timeLabel += min + ":";
        if (sec < 10) timeLabel += "0";
        timeLabel += sec;

        return timeLabel;
    }

    // show notification

    @Override
    protected void onResume() {
        super.onResume();
        Intent intent = new Intent(this, MusicService.class);
        bindService(intent, this, BIND_AUTO_CREATE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unbindService(this);
    }

    // for service - every time we call binder service on any of intent
    @Override
    public void onServiceConnected(ComponentName name, IBinder iBinder) {
        MusicService.MyBinder binder = (MusicService.MyBinder) iBinder;
        musicService = binder.getService();
        musicService.setCallBack(PlayerActivity.this);
        Log.e("Connected", musicService + "");
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        musicService = null;
        Log.e("Disconnected", musicService + "");

    }

    // chuyen qua Player
    public void showNotification(int playPauseBTN) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this,
                0, intent, 0);

        // previous button
        Intent prevIntent = new Intent(this, NotificationRecevier.class).setAction(ACTION_PREV);
        PendingIntent prevPendingIntent = PendingIntent.getBroadcast(this,
                0, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // previous button
        Intent playIntent = new Intent(this, NotificationRecevier.class).setAction(ACTION_PLAY);
        PendingIntent playPendingIntent = PendingIntent.getBroadcast(this,
                0, playIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // previous button
        Intent nextIntent = new Intent(this, NotificationRecevier.class).setAction(ACTION_NEXT);
        PendingIntent nextPendingIntent = PendingIntent.getBroadcast(this,
                0, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT);


//        String imageUrl = songList.get(position).getImageurl();
//        int resId = getResources().getIdentifier(imageUrl, "drawable", getPackageName());
//        Bitmap picture = BitmapFactory.decodeResource(getResources(), resId);
//        //Bitmap picture = BitmapFactory.decodeResource(getResources(), songList.get(position).getImageurl());
//        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID_2)
//                .setSmallIcon(songList.get(position).getImageurl())
//                .setLargeIcon(picture)
//                .setContentTitle(songList.get(position).getSongName())
//                .setContentText(songList.get(position).getSongArtist())
//                .addAction(R.drawable.ic_baseline_skip_previous_24,"Previous", prevPendingIntent)
//                .addAction(playPauseBTN,"Play", playPendingIntent)
//                .addAction(R.drawable.iconnext,"Next", nextPendingIntent)
//                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
//                        .setMediaSession(mediaSession.getSessionToken()))
//                .setPriority(NotificationCompat.PRIORITY_LOW)
//                .setContentIntent(contentIntent)
//                .setOnlyAlertOnce(true)
//                .build();

//        if (songList != null && position >= 0 && position < songList.size()) {
//            String imageUrl = songList.get(position).getImageurl();
//            int resId = getResources().getIdentifier(imageUrl, "drawable", getPackageName());
//            Bitmap picture = BitmapFactory.decodeResource(getResources(), resId);
//            // Build the notification using the image and other information
//
//            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID_2)
//                    .setSmallIcon(resId) // Use the resource ID here
//                    .setLargeIcon(picture)
//                    .setContentTitle(songList.get(position).getSongName())
//                    .setContentText(songList.get(position).getSongArtist())
//                    .addAction(R.drawable.ic_baseline_skip_previous_24, "Previous", prevPendingIntent)
//                    .addAction(playPauseBTN, "Play", playPendingIntent)
//                    .addAction(R.drawable.iconnext, "Next", nextPendingIntent)
//                    .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
//                            .setMediaSession(mediaSession.getSessionToken()))
//                    .setPriority(NotificationCompat.PRIORITY_LOW)
//                    .setContentIntent(contentIntent)
//                    .setOnlyAlertOnce(true)
//                    .build();
//
//            NotificationManager notificationManager = (NotificationManager)
//                    getSystemService(NOTIFICATION_SERVICE);
//
//            notificationManager.notify(0, notification);
//        }



//
//        Bitmap thumbnail = null;
//        if (picture != null) {
//            thumbnail = decodeByteArray(picture, 0, picture.length);
//        } else {    // nếu là null (không lấy được path của picture??? --> may be là vậy)
//            // thì lấy icon mặc định của android
//
//            thumbnail = decodeResource(getResources(), R.drawable.ic_launcher_foreground);
//        }


        // chưa lấy được hình ảnh của từng bài hát đẩy lên notification

        String picture = songList.get(position).getImageurl();
        Bitmap pictureBitmap = BitmapFactory.decodeFile(picture);
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID_2)
                .setSmallIcon(R.drawable.dusk)
                .setLargeIcon(pictureBitmap)
                .setContentTitle(songList.get(position).getSongName())
                .setContentText(songList.get(position).getSongArtist())
                .addAction(R.drawable.ic_baseline_skip_previous_36, "Previous", prevPendingIntent)
                .addAction(R.drawable.nutpause, "Pause", playPendingIntent)
                .addAction(R.drawable.ic_baseline_skip_next_36, "Next", nextPendingIntent)
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setMediaSession(mediaSessionCompat.getSessionToken()))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setOnlyAlertOnce(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setSound(null)
                .build();
        //musicService.startForeground(1, notification);
        NotificationManager notificationManager = (NotificationManager)
                    getSystemService(NOTIFICATION_SERVICE);

            notificationManager.notify(0, notification);
    }

    private byte[] getAlbumArt(String uri)
            throws IOException {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(uri);
        byte[] art = retriever.getEmbeddedPicture();
        retriever.release();
        return art;
    }


    // implement some functions in Interface ActionPlaying

    private void nextThreadbtn() {
        nextThread = new Thread() {
            @Override
            public void run() {
                super.run();
                btnNext.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        nextClicked();
                    }
                });
            }
        };
        nextThread.start();
    }

    // triển khai interface --> dungftrong
    // MusicService class thi vì phải viết lại từng dòng code
    public void nextClicked() {

            if (position < songList.size() - 1) {
                position++;
            } else {
                position = 0;

            }
            initPlayer(position);
    }


    @Override
    public void previousClicked() {
        if (position <= 0) {
            position = songList.size() - 1;
        } else {
            position--;
        }

        initPlayer(position);
    }

    @Override
    public void playClicked() {
        if (mediaPlayer.isPlaying()) {
            btnPlay.setBackgroundResource(R.drawable.nutpause);
            mediaPlayer.pause();
        } else {
            btnPlay.setBackgroundResource(R.drawable.nutplay);
            mediaPlayer.start();
        }
    }


}








