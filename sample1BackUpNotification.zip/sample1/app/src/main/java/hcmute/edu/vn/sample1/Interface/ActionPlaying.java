package hcmute.edu.vn.sample1.Interface;

public interface ActionPlaying {
    void nextClicked();

    void previousClicked();

    void playClicked();
}
