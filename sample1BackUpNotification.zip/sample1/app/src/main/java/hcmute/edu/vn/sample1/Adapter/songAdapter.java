//package hcmute.edu.vn.sample1.Adapter;
//
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import hcmute.edu.vn.sample1.R;
//
//public class songAdapter extends RecyclerView.Adapter<songAdapter.ViewHolder>{
//
//    @NonNull
//    @Override
//    public songAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        return null;
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull songAdapter.ViewHolder holder, int position) {
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return 0;
//    }
//
//    public class ViewHolder extends RecyclerView.ViewHolder {
//
//        public TextView songName;
//        public TextView songArtist;
//        public ImageView songImage;
//
//        public ViewHolder(View itemView) {
//            super(itemView);
//
//            songName = (TextView) itemView.findViewById(R.id.s);
//            songArtist = (TextView) itemView.findViewById(R.id.song_artist);
//            songImage = (ImageView) itemView.findViewById(R.id.song_image);
//        }
//    }
//}
